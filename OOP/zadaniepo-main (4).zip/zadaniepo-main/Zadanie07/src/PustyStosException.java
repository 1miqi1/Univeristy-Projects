public class PustyStosException extends Exception {
}
