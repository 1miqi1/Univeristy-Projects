public class BłędnaNotacjaException extends Exception {

}
