public class Main {
    public static void main(String[] args) throws BłędnaNotacjaException {
        ONP.uruchom();
        // Nieprawidłowy 10/
        // Prawidłowy 123*+
    }
}
