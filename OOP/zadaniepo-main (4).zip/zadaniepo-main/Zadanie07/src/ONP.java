import java.util.Scanner;

public class ONP {
    public static final int WIELK = 503;

    public static boolean czyOperator(char znak){
        return znak == '+' || znak == '-' || znak == '*' || znak == '/' ;
    }

    public static int znakNaLiczbe(char znak){
        return znak-'0';
    }

    public static int obliczWynik(int a, int b, char znak)
        throws IllegalArgumentException, ArithmeticException{
        switch (znak) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if(b == 0){
                    throw new ArithmeticException("Dzielenie przez 0");
                }
                return a / b;
            default:
                throw new IllegalArgumentException("Nieprawidłowy operator:"+znak);
        }
    }

    public static int skanuj(String s) throws BłędnaNotacjaException{
      try{
          int wsk = 0;
          Stos p = new Stos(WIELK);
          while(wsk < s.length()){
              char znak = s.charAt(wsk++);
              if(czyOperator(znak)){
                  int el2 = p.wierzch();
                  p.zdejmij();
                  int el1 = p.wierzch();
                  p.zdejmij();
                  p.dodaj(obliczWynik(el1,el2,znak));
              }
              else if('0' <= znak && znak <= '9'){
                  p.dodaj(znakNaLiczbe(znak));
              }else {
                  throw new BłędnaNotacjaException();
              }
          }
          int zwrot = p.wierzch();
          p.zdejmij();
          if(!p.czyPusty()){
              throw  new BłędnaNotacjaException();
          }
          return zwrot;
      } catch (PustyStosException | PełnyStosException | ArithmeticException e) {
          throw new BłędnaNotacjaException();
      }
    }

    public static void uruchom() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Wprowadź wyrażenia, jedno w każdej linii. Zakończ wprowadzanie, wpisując pustą linię.");

        while (scanner.hasNextLine()) {
            String wyrazenie = scanner.nextLine();
            if (wyrazenie.isEmpty()) {
                break;
            }
            try{
                System.out.println("Wczytano: " + wyrazenie);
                System.out.printf("Wynik to %d\n", skanuj(wyrazenie));
            } catch (BłędnaNotacjaException e){
                System.out.println("Nieprawidłowe wejście");
            }
        }

        scanner.close();
    }
}
