public class PełnyStosException extends RuntimeException{
}