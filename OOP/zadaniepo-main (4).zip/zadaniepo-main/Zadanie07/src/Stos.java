import javax.lang.model.element.PackageElement;

public class Stos {
    private int ost;
    private int[] stos;

    public Stos(int n) {
        ost = 0;
        stos = new int[n];
    }

    public boolean czyPusty() {
        return ost == 0;
    }

    public boolean czyPelny() {
        return ost == stos.length;
    }

    public void dodaj(int x) throws PełnyStosException {
        if(czyPelny()) throw new PełnyStosException();
        stos[ost] = x;
        ost++;
    }

    public void zdejmij() throws PustyStosException{
        if(czyPusty()) throw new PustyStosException();
        ost -- ;
    }

    public int wierzch() throws PustyStosException{
        if(czyPusty()) throw new PustyStosException();
        return stos[ost-1];
    }
}
