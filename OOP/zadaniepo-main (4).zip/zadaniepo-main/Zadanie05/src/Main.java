//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("***dzien1***");
        Data dzien1 = new Data(15, 4, 2025);
        System.out.printf("Wypisanie parametrów: Dzień %d, Miesiąc %d, Rok %d\n",
                dzien1.getDzien(), dzien1.getMiesiac(), dzien1.getRok());
        System.out.println("Data: " + dzien1);
        System.out.printf("Rok przestępny: %b\nLiczba dni w roku/miesiącu: %d/%d\n",
                dzien1.czyPrzestepny(), dzien1.rokLiczbaDni(), dzien1.miesiacLiczbaDni());

        Data jutro = dzien1.jutro();
        System.out.println("Jutro: " + jutro);

        Data wczoraj = dzien1.wczoraj();
        System.out.println("Wczoraj: " + wczoraj);

        dzien1.przesun(1000);
        System.out.println("Za 1000 dni będzie: " + dzien1.toString());
        dzien1.przesun(-1000);
        System.out.println("przypomnienie: dzien1 = " + dzien1.toString());

        Data dzien2 = new Data(29, 2, 2028);
        System.out.println("dzień2: " + dzien2.toString());
        System.out.printf("czy dzien1 jest jest rowny/wczesniej od dzien2: %b/%b\n",
                dzien1.czyRowne(dzien2), dzien1.czyWczesniej(dzien2));
        System.out.printf("ile dni minelo od dzien1 do dzien2: %d\n", dzien1.ileMinelo(dzien2));
        System.out.println("KONIEC");
    }
}