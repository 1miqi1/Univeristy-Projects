public class Data {
    private int dzien;
    private int miesiac;
    private int rok;

    private static final int[] LICZBA_DNI_W_MIESIACACH = {
            31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
    };

    public Data(int dzien, int miesiac, int rok) {
        this.rok = rok;
        this.miesiac = miesiac;
        this.dzien = dzien;

        assert (0 < miesiac && miesiac <= 12) : "Niepoprawny miesiąc";
        assert (0 < dzien && dzien < miesiacLiczbaDni()) : "Niepoprawny dzien";
    }

    public int getDzien() {
        return dzien;
    }

    public int getMiesiac() {
        return miesiac;
    }

    public int getRok() {
        return rok;
    }

    public String toString() {
        return String.format("%04d-%02d-%02d", rok, miesiac, dzien);
    }

    public boolean czyPrzestepny() {
        return (rok % 4 == 0 && rok % 100 != 0) || (rok % 400 == 0);
    }

    public int rokLiczbaDni() {
        return czyPrzestepny() ? 366 : 365;
    }

    public int miesiacLiczbaDni() {
        if (miesiac == 2 && czyPrzestepny()) {
            return 29;
        }
        return LICZBA_DNI_W_MIESIACACH[miesiac - 1];
    }

    public boolean czyRowne(Data data2) {
        return this.dzien == data2.dzien &&
                this.miesiac == data2.miesiac &&
                this.rok == data2.rok;
    }

    public boolean czyWczesniej(Data data2) {
        if (this.rok != data2.rok) {
            return this.rok < data2.rok;
        }
        if (this.miesiac != data2.miesiac) {
            return this.miesiac < data2.miesiac;
        }
        return this.dzien < data2.dzien;
    }

    public void przesun(int n) {
        if (n == 0) return;

        if (n > 0) {
            if (dzien == miesiacLiczbaDni()) {
                dzien = 1;
                if (miesiac == 12) {
                    miesiac = 1;
                    rok++;
                } else {
                    miesiac++;
                }
            } else {
                dzien++;
            }
            przesun(n - 1);
        } else { // n < 0
            if (dzien == 1) {
                if (miesiac == 1) {
                    miesiac = 12;
                    rok--;
                } else {
                    miesiac--;
                }
                dzien = miesiacLiczbaDni();
            } else {
                dzien--;
            }
            przesun(n + 1);
        }
    }

    public Data jutro() {
        Data kopia = new Data(dzien, miesiac, rok);
        kopia.przesun(1);
        return kopia;
    }

    public Data wczoraj() {
        Data kopia = new Data(dzien, miesiac, rok);
        kopia.przesun(-1);
        return kopia;
    }

    public int ileMinelo(Data data2) {
        Data tmp = new Data(dzien, miesiac, rok);
        int sign = tmp.czyWczesniej(data2) ? 1 : -1;
        int licznik = 0;

        while (!tmp.czyRowne(data2)) {
            tmp.przesun(sign);
            licznik += sign;
        }
        return licznik;
    }
}
