package main.totolotek.pomocniczeklasy;

public final class Stałe {
    public static final int MAXLICZBALOSOWAŃ = 10;
    public static final int MAXLICZBAZAKŁADÓW = 8;
    public static final int LICZBANUMERÓW = 49;
    public static final int DŁUGOŚĆZAKŁADU = 6;
    public static final long CENAZAKŁADU= 300;
    public static final long PODATEKODZAKŁDAU = 60 ;
}
