package main.totolotek.wyjątki;

public class ZłaKolektura extends Exception {
    public ZłaKolektura(String message) {
        super(message);
    }
}
