# Testowanie aplikacji

Testowanie pisanego przez nas kodu jest bardzo ważne - im większy projekt, tym większa szansa, że gdzieś w nim znajdują się błędy.
Dotychczas pisane programy były relatywnie małe, więc sensownym było testować je w całości - stworzyć zestawy danych wejściowych wraz z oczekiwanymi wynikami. Takie testy zwykle określa się *testami end-to-end*, bo testują nasz program z pespektywy użytkownika końcowego.

Na tym przedmiocie będziecie jednak musieli napisać większe programy, składające się z wielu klas, przy których znalezienie źródła błędu przy pomocy informacji o niezaliczonym teście end-to-end może być bardzo trudne. Do testowania tego typu programów idealnie sprawdzą się *testy jednostkowe*. Przy tworzeniu takich testów bierzemy na warsztat jedną klasę i staramy się przetestować wszystkie możliwe sposoby jej użycia.

W naprawdę dużych projektach mogą pojawić się jeszcze *testy integracyjne*, które sprawdzają integrację całego modułu (składającego się na przykład z wielu klas) z resztą systemu. Oczywiście istnieje też wiele innych rodzajów testów, ale na tych zajęciach skupimy się na testach jednostkowych.

# Testy jednostkowe w Javie - biblioteka JUnit

W Javie najpopularniejszą biblioteką do pisania testów jednostkowych jest *JUnit* (aktualnie w wersji 5).

Instrukcja załączenia biblioteki JUnit do projektu w IntelliJ IDEA:
1. Otwórz File -> Project Structure
2. Wybierz zakładkę Libraries
3. Kliknik + i z listy wybierz From Maven...
4. Wyszukaj biblioteki org.junit.jupiter i wybierz najnowszą wersję - w moim przypadku jest to org.junit.jupiter:junit-jupiter:5.9.2. Zaznacz Javadocs i Annotations i kliknij OK.

W małym projekcie, niekorzystającym z żadnego menedżera zależności, pliki z testami można umieszczać na przykład w tym samym folderze, w którym znajdują się testowane klasy.
Takie rozwiązanie może być jednak dość niewygodne - nagle liczba plików w pakiecie rośnie dwukrotnie (zakłądając, że dla każdej klasy mamy jeden plik z testami).
W większych projektach (opartych np na Mavenie albo Gradle'u) utarło się umieszczać pliki z testami w "lustrzanym" folderze względem testowanej klasy.
Przykładowo, możemy mieć taką hierarchię folderów:
* src
    * main2
        * java
            * org
                * example
                    * Fraction.java
    * test
        * java
            * org
                * example
                    * FractionTest.java


Przyjrzyjmy się testom jednostkowym na przykładzie klasy Fraction reprezentującej liczby wymierne.
Testy do tej klasy znajdują się w FractionTest.
# Klasa
```java

public class Fraction {
    private int numerator;
    private int denominator;

    public Fraction(int numerator, int denominator) {
        if (denominator == 0) {
            throw new ArithmeticException("The denominator cannot be equal to 0.");
        }
        this.numerator = numerator;
        this.denominator = denominator;
        normalise();
    }

    public int getNumerator() {
        return numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    public double toDouble() {
        return ((double) numerator) / denominator;
    }

    @Override
    public String toString() {
        return getNumerator() + "/" + getDenominator();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Fraction) {
            Fraction other = (Fraction) obj;
            return numerator == other.numerator && denominator == other.denominator;
        }
        return false;
    }

    public void add(Fraction other) {
        int otherDenominator = other.denominator;
        numerator = numerator * other.denominator + other.numerator * denominator;
        denominator *= otherDenominator;
        normalise();
    }

    public void subtract(Fraction other) {
        int otherDenominator = other.denominator;
        numerator = numerator * other.denominator - other.numerator * denominator;
        denominator *= otherDenominator;
        normalise();
    }

    public void multiply(Fraction other) {
        numerator *= other.numerator;
        denominator *= other.denominator;
        normalise();
    }

    public void divide(Fraction other) {
        if (other.numerator == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        numerator *= other.denominator;
        denominator *= other.numerator;
        normalise();
    }

    private void normalise() {
        if (denominator < 0) {
            numerator *= -1;
            denominator *= -1;
        }

        int gcd = gcd(numerator, denominator);
        numerator /= gcd;
        denominator /= gcd;
    }

    private static int gcd(int x, int y) {
        if (x < 0)
            return gcd(-x, y);
        else
            return x == 0 ? y : gcd(y % x, x);
    }
}

```
# Przykład 1 testy do klasy Fraction
```java
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FractionTests {

    @Test
    public void shouldConvertFractionToString() {
        // given
        Fraction fraction = new Fraction(2, 5);

        // then
        assertEquals("2/5", fraction.toString());
    }

    @Test
    public void shouldConvertFractionToDouble() {
        // given
        Fraction fraction = new Fraction(2, 5);

        // then
        assertEquals(2.0 / 5, fraction.toDouble());
    }

    @Test
    public void shouldThrowExceptionWhenDenominatorIsZero() {
        // then
        assertThrows(ArithmeticException.class, () -> new Fraction(1, 0));
    }

    @Test
    public void shouldTwoSameFractionsBeEqual() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(4, 10);

        // then
        assertEquals(fraction1, fraction2);
    }

    @Test
    public void shouldTwoDifferentFractionsNotBeEqual() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(3, 5);

        // then
        assertNotEquals(fraction1, fraction2);
    }

    @Test
    public void shouldNegatingNumeratorAndDenominatorCancelEachOtherOut() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(-2, -5);

        // then
        assertEquals(fraction1, fraction2);
    }

    @Test
    public void shouldAddTwoFractions() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(3, 5);
        Fraction fraction3 = new Fraction(1, 1);

        // when
        fraction1.add(fraction2);

        // then
        assertEquals(fraction3, fraction1);
    }

    @Test
    public void shouldSubtractTwoFractions() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(3, 5);
        Fraction fraction3 = new Fraction(-1, 5);

        // when
        fraction1.subtract(fraction2);

        // then
        assertEquals(fraction3, fraction1);
    }

    @Test
    public void shouldAddFractionToItself() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(4, 5);

        // when
        fraction1.add(fraction1);

        // then
        assertEquals(fraction2, fraction1);
    }

    @Test
    public void shouldSubtractFractionFromItself() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(0, 1);

        // when
        fraction1.subtract(fraction1);

        // then
        assertEquals(fraction2, fraction1);
    }

    @Test
    public void shouldMultiplyTwoFractions() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(3, 5);
        Fraction fraction3 = new Fraction(6, 25);

        // when
        fraction1.multiply(fraction2);

        // then
        assertEquals(fraction3, fraction1);
    }

    @Test
    public void shouldDivideTwoFractions() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(3, 5);
        Fraction fraction3 = new Fraction(2, 3);

        // when
        fraction1.divide(fraction2);

        // then
        assertEquals(fraction3, fraction1);
    }

    @Test
    public void shouldThrowExceptionWhenDividingByFractionEqualToZero() {
        // given
        Fraction fraction1 = new Fraction(2, 5);
        Fraction fraction2 = new Fraction(0, 1);

        // then
        assertThrows(ArithmeticException.class, () -> fraction1.divide(fraction2));
    }
}
```


# Zadanie 1

Uruchom testy dla klasy Fraction


# Asercje w JUnit 5
Przyjrzymy się najpopularniejszym asercjom

1,- **`assertEquals(expected, actual)`**: Sprawdza, czy dwie wartości są równe.

2,**`assertNotEquals(unexpected, actual)`**: Sprawdza, czy dwie wartości są różne.

3,**`assertTrue(condition)`**: Sprawdza, czy podany warunek jest prawdziwy.

4.**`assertFalse(condition)`**: Sprawdza, czy podany warunek jest fałszywy.

5,**`assertNull(value)`**: Sprawdza, czy podana wartość jest `null`.

6,**`assertNotNull(value)`**: Sprawdza, czy podana wartość nie jest `null`.

7.**`assertSame(expected, actual)`**: Sprawdza, czy dwie referencje wskazują na ten sam obiekt.

8.**`assertNotSame(unexpected, actual)`**: Sprawdza, czy dwie referencje wskazują na różne obiekty.

9.**`assertThrows(expectedExceptionType, executable)`**: Sprawdza, czy podany kod rzuca wyjątek oczekiwanego typu.

10.**`assertTimeout(duration, executable)`**: Sprawdza, czy podany kod kończy się w określonym czasie.

11.**`assertTimeoutPreemptively(duration, executable)`**: Podobnie jak `assertTimeout`, ale natychmiast przerywa wykonywanie kodu po przekroczeniu czasu.

12.**`assertIterableEquals(expected, actual)`**: Sprawdza, czy dwie kolekcje są równe (tzn. mają tę samą kolejność i zawartość elementów).

13.**`assertArrayEquals(expected, actual)`**: Sprawdza, czy dwie tablice są równe (tzn. mają tę samą długość i zawartość elementów).

14.**`assertLinesMatch(expected, actual)`**: Sprawdza, czy listy tekstów są równe, biorąc pod uwagę dopasowanie wzorca (np. wyrażeń regularnych).

15.**`assertAll(executables)`**: Pozwala na grupowanie wielu asercji w jednym bloku.

# Zadanie 2
Pobaw się asercjami

# Asercje w JUnit 5 - Kontynuacja

16,**`assertDoesNotThrow(executable)`**: Sprawdza, czy podany kod nie rzuca żadnego wyjątku.

17.**`assertAll(message, executables)`**: Pozwala na grupowanie wielu asercji w jednym bloku, jednocześnie dostarczając wiadomość, która zostanie wyświetlona w przypadku niepowodzenia którejkolwiek z asercji.

18,**`fail()`**: Powoduje nieudane zakończenie testu bez żadnych dodatkowych warunków.

19.**`fail(message)`**: Powoduje nieudane zakończenie testu z podaną wiadomością.

20.**`assumeTrue(condition)`**: Przerywa wykonywanie testu, jeśli podany warunek nie jest prawdziwy. Test nie zostanie uznany za nieudany, ale zostanie pominięty.

21.**`assumeFalse(condition)`**: Przerywa wykonywanie testu, jeśli podany warunek jest prawdziwy. Test nie zostanie uznany za nieudany, ale zostanie pominięty.

22,**`assumingThat(condition, executable)`**: Wykonuje blok kodu tylko wtedy, gdy podany warunek jest prawdziwy. Pozwala na warunkowe wykonanie części testu.


# JUnit 5 Adnotacje

1. **@Test**: Oznacza metodę jako test jednostkowy. Ta metoda zostanie uruchomiona przez test runner JUnit, aby przetestować określoną część kodu.

2. **@BeforeEach**: Oznacza metodę, która zostanie uruchomiona przed każdym testem w klasie testowej. Jest to przydatne, gdy chcemy zresetować stan obiektów, przygotować dane wejściowe lub zasoby przed każdym testem.

3. **@AfterEach**: Oznacza metodę, która zostanie uruchomiona po każdym zakończonym teście w klasie testowej. Jest to przydatne, gdy chcemy posprzątać po teście, zwolnić zasoby lub zarejestrować wynik.

4. **@BeforeAll**: Oznacza metodę, która zostanie uruchomiona tylko raz przed wszystkimi testami w klasie testowej. Jest to przydatne, gdy chcemy zainicjować zasoby, które są wspólne dla wszystkich testów i mogą być kosztowne czasowo.

5. **@AfterAll**: Oznacza metodę, która zostanie uruchomiona tylko raz po zakończeniu wszystkich testów w klasie testowej. Jest to przydatne, gdy chcemy zwolnić wspólne zasoby dla wszystkich testów.

6. **@DisplayName**: Pozwala na nadanie czytelnej nazwy testowi, która będzie wyświetlana podczas uruchamiania testów. Jest to szczególnie przydatne, gdy chcemy dodać opisowe informacje o teście.

7. **@Disabled**: Oznacza test jako wyłączony. Test runner JUnit nie będzie uruchamiał testu oznaczonego tą adnotacją. Jest to przydatne, gdy chcemy tymczasowo wyłączyć niektóre testy.

8. **@Nested**: Oznacza klasę wewnętrzną jako zagnieżdżoną klasę testową. Umożliwia grupowanie testów związanych z określoną funkcjonalnością lub kontekstem.

9. **@Tag**: Pozwala na przypisanie etykiet do testów, co umożliwia filtrowanie testów podczas uruchamiania na podstawie przypisanych etykiet.

10. **@Timeout**: Ustawia limit czasu dla danego testu. Jeśli test przekroczy określony limit czasu, zostanie uznany za nieudany.

11. **@ExtendWith**: Umożliwia rozszerzenie JUnit 5 za pomocą własnych rozszerzeń, takich jak dodatkowe operacje przed uruchomieniem testów, rejestratory wyników itp.

12. **@ParameterizedTest**: Oznacza metodę jako test parametryzowany, który pozwala na uruchomienie testu z róznymi parametrami

13. **@RepeatedTest**: Oznacza metodę jako test, który zostanie wykonany wielokrotnie z określoną liczbą powtórzeń. Pozwala to na łatwe sprawdzenie stabilności i niezawodności kodu podczas wykonywania tego samego testu wiele razy.

14. **@TestFactory**: Oznacza metodę jako dynamiczną metodę testową, która zwraca kolekcję obiektów `DynamicTest` lub `DynamicContainer`. Umożliwia to tworzenie testów w sposób programistyczny, zamiast deklaratywny, co pozwala na generowanie testów w czasie wykonania.

15. **@TestInstance**: Używana na poziomie klasy testowej, pozwala kontrolować cykl życia instancji testów. Domyślnie, JUnit tworzy nową instancję klasy testowej dla każdego testu, ale za pomocą tej adnotacji można zmienić zachowanie na `Lifecycle.PER_CLASS`, co oznacza, że tylko jedna instancja klasy testowej zostanie utworzona dla wszystkich testów w klasie.



##  zadanie 3
Napisz testy do wybranego zadania algorytmicznego realizowanego na poprzednich zajęciach np zadania o osobistości
użyj odpowiednie asercji badź adnotacji ktora pozwoli odróżniać rozowiązania o(n^2) od O(n)

Pokażemy teraz jak przerobić nasze testy z wykorzystaniem adnotacji @BeforeEach
## przykład 2
```java
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class FractionTestV2 {

    private Fraction fraction1;
    private Fraction fraction2;
    private Fraction fraction3;

    @BeforeEach
    void setUp() {
        fraction1 = new Fraction(1, 2);
        fraction2 = new Fraction(2, 3);
        fraction3 = new Fraction(3, 4);
    }

    // Teraz dodajemy testy
    @Test
    void testAdd() {
        fraction1.add(fraction2);
        assertEquals(new Fraction(7, 6), fraction1);
    }

    @Test
    void testSubtract() {
        fraction1.subtract(fraction2);
        assertEquals(new Fraction(-1, 6), fraction1);
    }

    @Test
    void testMultiply() {
        fraction1.multiply(fraction2);
        assertEquals(new Fraction(1, 3), fraction1);
    }

    @Test
    void testDivide() {
        fraction1.divide(fraction2);
        assertEquals(new Fraction(3, 4), fraction1);
    }

    @Test
    void testDivideByZero() {
        assertThrows(ArithmeticException.class, () -> fraction1.divide(new Fraction(0, 1)));
    }

    @Test
    void testToString() {
        assertEquals("1/2", fraction1.toString());
        assertEquals("2/3", fraction2.toString());
        assertEquals("3/4", fraction3.toString());
    }

    @Test
    void testEquals() {
        Fraction anotherFraction1 = new Fraction(1, 2);
        assertEquals(fraction1, anotherFraction1);
    }
}


```

oraz jak przerobić te testy na testy parametryzowane:

## Przykład 3
```java
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

class FractionTestParam {
    @ParameterizedTest
    @CsvSource({
            "1, 2, 1, 4, 3, 4",
            "1, 3, 2, 3, 1, 1",
            "2, 5, 3, 5, 1, 1",
            "-1, 2, 1, 6, -1, 3"
    })
    void testAdd(int num1, int den1, int num2, int den2, int expectedNum, int expectedDen) {
        Fraction fraction1 = new Fraction(num1, den1);
        Fraction fraction2 = new Fraction(num2, den2);
        fraction1.add(fraction2);

        Fraction expectedFraction = new Fraction(expectedNum, expectedDen);
        assertEquals(expectedFraction, fraction1);
    }
}


```
## Zadanie 3

Dana jest klasa Polynomial reprezentująca wielomian. Dopisz do niej testy jednostkowe, a
nastepnie przerób je tak, aby używały @beforeEach lub parametryzacji

```java
public class Polynomial {
    double[] coefficients;

    public Polynomial(double[] coefficients) {
        this.coefficients = coefficients;
    }

    public Polynomial add(Polynomial other) {
        double[] result = new double[Math.max(coefficients.length, other.coefficients.length)];

        for (int i = 0; i < coefficients.length; i++) {
            result[i] += coefficients[i];
        }

        for (int i = 0; i < other.coefficients.length; i++) {
            result[i] += other.coefficients[i];
        }

        return new Polynomial(result);
    }

    public Polynomial subtract(Polynomial other) {
        double[] result = new double[Math.max(coefficients.length, other.coefficients.length)];

        for (int i = 0; i < coefficients.length; i++) {
            result[i] += coefficients[i];
        }

        for (int i = 0; i < other.coefficients.length; i++) {
            result[i] -= other.coefficients[i];
        }

        return new Polynomial(result);
    }

    public Polynomial multiply(Polynomial other) {
        double[] result = new double[coefficients.length + other.coefficients.length - 1];

        for (int i = 0; i < coefficients.length; i++) {
            for (int j = 0; j < other.coefficients.length; j++) {
                result[i + j] += coefficients[i] * other.coefficients[j];
            }
        }

        return new Polynomial(result);
    }

    public double evaluate(double x) {
        double result = 0;

        for (int i = coefficients.length - 1; i >= 0; i--) {
            result = result * x + coefficients[i];
        }

        return result;
    }

    public Polynomial derivative() {
        if (coefficients.length <= 1) {
            return new Polynomial(new double[]{0});
        }

        double[] derivativeCoefficients = new double[coefficients.length - 1];

        for (int i = 1; i < coefficients.length; i++) {
            derivativeCoefficients[i - 1] = coefficients[i] * i;
        }

        return new Polynomial(derivativeCoefficients);
    }

    public Polynomial integral() {
        double[] integralCoefficients = new double[coefficients.length + 1];

        for (int i = 0; i < coefficients.length; i++) {
            integralCoefficients[i + 1] = coefficients[i] / (i + 1);
        }

        return new Polynomial(integralCoefficients);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int i = coefficients.length - 1; i >= 0; i--) {
            if (coefficients[i] == 0) continue;
            if (sb.length() > 0 && coefficients[i] > 0) {
                sb.append(" + ");
            }
            if (i == 0 || coefficients[i] != 1) {
                sb.append(coefficients[i]);
            }
            if (i > 0) {
                sb.append("x");
            }
            if (i > 1) {
                sb.append("^").append(i);
            }
        }

        return sb.toString();
    }
}



```