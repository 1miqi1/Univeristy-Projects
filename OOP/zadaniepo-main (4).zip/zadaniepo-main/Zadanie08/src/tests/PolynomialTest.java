package tests;
import main.Polynomial;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class PolynomialTest {
    @Test
    public void constructorNormalizer() {
        // Konstruktor ucina zera wiodące.
        assertEquals(new Polynomial(new double[]{1,2,3,0,0}), new Polynomial(new double[]{1,2,3}));
        assertEquals(new Polynomial(new double[]{0,0}), new Polynomial(new double[]{0}));
        assertThrows(IllegalArgumentException.class, () -> new Polynomial(new double[]{}));
    }

    @Test
    public void addTest(){
        // Add dobrze sumuje dwa zwyczajne wielomiany tego samego stopnia (większego niż 1).
        Polynomial p1 = new Polynomial(new double[]{1,2,3});
        Polynomial p2 = new Polynomial(new double[]{10,20,30});
        assertEquals(new Polynomial(new double[]{11,22,33}),p1.add(p2));

        // Add dobrze sumuje dwa zwyczajne wielomiany różnych stopni (większych niż 1).
        Polynomial p3 = new Polynomial(new double[]{10,20,30,40});
        assertEquals(new Polynomial(new double[]{11,22,33,40}), p3.add(p1));

        // Add radzi sobie z przypadkami brzegowymi – wielomian zerowego stopnia jako 1) lewy argument, 2) prawy argument, 3) oba argumenty.
        Polynomial zero1 = new Polynomial(new double[]{0});
        Polynomial zero2 = new Polynomial(new double[]{0});
        assertEquals(zero1.add(zero2), zero2);
        assertEquals(p1,p1.add(zero1));
        assertEquals(zero1.add(p1),p1);

        // Wynik add nie ma zer wiodących, nawet jeśli najwyższe współczynniki się wyzerują.
        Polynomial p4 = new Polynomial(new double[]{1,2,3,4,5});
        Polynomial p5 = new Polynomial(new double[]{1,2,3,-4,-5});
        assertEquals(p4.add(p5), new Polynomial(new double[]{2,4,6}));
    }

    @Test
    public void evaluateTest(){
        // Evaluate dobrze wylicza zwyczajny wielomian stopnia > 1.
        Polynomial p1 = new Polynomial(new double[]{1,2,3});
        assertEquals(1, p1.evaluate(0));
        assertEquals(6, p1.evaluate(1));
        assertEquals(17, p1.evaluate(2));

        // Evaluate dobrze wylicza zwyczajny wielomian stopnia > 1 o niecałkowitych współczynnikach w niecałkowitym punkcie
        Polynomial p2 = new Polynomial(new double[]{0.33,1.33,2.5});
        assertEquals(p2.evaluate(0.5), 1.62);
        assertEquals(p2.evaluate(1.5), 7.95);

        // Evaluate radzi sobie z przypadkiem brzegowym – wielomianem stopnia zerowego.
        Polynomial zero1 = new Polynomial(new double[]{0});
        assertEquals(0, zero1.evaluate(0));
        assertEquals(0, zero1.evaluate(1));
        assertEquals(0, zero1.evaluate(2));
    }

    @Test
    public void toStringTest(){
        // toString dobrze wypisuje zwyczajny wielomian stopnia
        Polynomial p1 = new Polynomial(new double[]{7,2,3});
        assertEquals("3.0x^2 + 2.0x + 7.0", p1.toString());

        // toString dobrze wypisuje zwyczajny wielomian stopnia > 1.
        Polynomial p2 = new Polynomial(new double[]{0,0,7});
        assertEquals("7.0x^2", p2.toString());

        // toString pomija współczynniki = 1.
        Polynomial p3 = new Polynomial(new double[]{1,1,1});
        assertEquals("x^2 + x + 1.0", p3.toString());

        // toString dobrze wypisuje wielomian zerowy.
        Polynomial p4 = new Polynomial(new double[]{0});
        assertEquals("", p4.toString());
    }

}