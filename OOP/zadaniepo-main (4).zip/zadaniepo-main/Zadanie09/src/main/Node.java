package main;

interface Node<T extends Comparable<T>> {
    Node<T> insert(T value);
    String toString();
}
