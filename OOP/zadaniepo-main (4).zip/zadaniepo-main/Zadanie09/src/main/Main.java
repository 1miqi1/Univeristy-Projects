package main;

public class Main {
    public static void main(String[] args) {
        BST<Integer> bst_int = new BST<>();
        bst_int.insert(5);
        bst_int.insert(3);
        bst_int.insert(4);
        bst_int.insert(2);
        bst_int.insert(7);
        System.out.println(bst_int);

        BST<Godzina> bst_time = new BST<>();
        bst_time.insert(new Godzina(5,4));
        bst_time.insert(new Godzina(3,40));
        bst_time.insert(new Godzina(3,1));
        bst_time.insert(new Godzina(7,10));
        bst_time.insert(new Godzina(20,40));
        bst_time.insert(new Godzina(6,4));
        System.out.println(bst_time);
    }
}
