package main;

class StubNode<T extends Comparable<T>> implements Node<T> {
    @Override
    public Node<T> insert(T value) {
        return new ValueNode<>(value);
    }

    @Override
    public String toString(){
        return "";
    }
}
