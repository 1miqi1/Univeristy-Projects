package main;

public class BST<T extends Comparable<T>> {
    private Node<T> root;

    public BST() {
        this.root = new StubNode<>();
    }

    public void insert(T value){
        this.root = root.insert(value);
    }

    @Override
    public String toString(){
        return root.toString();
    }
}
