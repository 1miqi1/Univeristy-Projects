package main;

class ValueNode<T extends Comparable<T>> implements Node<T> {
    private final T value;
    private Node<T> left;
    private Node<T> right;

    public ValueNode(T value) {
        this.value = value;
        this.left = new StubNode<>();
        this.right = new StubNode<>();
    }

    @Override
    public Node<T> insert(T value) {
        if(this.value.compareTo(value) > 0) {
             this.left = this.left.insert(value);
        }else if(this.value.compareTo(value) < 0) {
             this.right = this.right.insert(value);
        }
        return this;
    }

    @Override
    public String toString() {
        return this.left.toString() + " " + this.value.toString() +  this.right.toString();
    }
}
