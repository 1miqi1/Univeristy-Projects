package main;

public class Godzina implements Comparable<Godzina> {
    private int godzina;
    private int minuta;
    private static final int MAX_MINUTA = 59;
    private static final int MAX_GODZINA = 23;

    public Godzina(int godzina, int minuta) {
        assert 0 <= godzina && godzina <= MAX_GODZINA;
        assert 0 <= minuta && minuta <= MAX_MINUTA;
        this.godzina = godzina;
        this.minuta = minuta;
    }

    @Override
    public String toString() {
        return "%02d-%02d".formatted(this.godzina, this.minuta);
    }

    @Override
    public int compareTo(Godzina g) {
        return (this.godzina*100+this.minuta) - (g.godzina*100+g.minuta);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Godzina)){
            return false;
        }
        return this.compareTo((Godzina)o) == 0;
    }
}
