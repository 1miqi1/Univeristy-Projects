# ZadaniePO

This repository contains individual Java programming tasks as separate modules.

## 📁 Structure

Each folder is an independent task:

- `Zadanie1`: Short description of the first task (e.g. basic calculator)
- `Zadanie2`: Short description of the second task (e.g. file parser)

## 🧠 Notes

- Projects are fully self-contained.
- You can open `ZadaniePO` in IntelliJ IDEA and work on each module separately.
- Java files are stored in `src/` folders inside each module.
